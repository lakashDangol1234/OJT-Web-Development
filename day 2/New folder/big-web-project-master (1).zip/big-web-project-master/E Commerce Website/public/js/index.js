let navbar_menu=document.querySelector('.nav-menu');
let nav_links=document.querySelector('.nav-links');
navbar_menu.addEventListener('click',()=>{
    nav_links.classList.toggle('active');
})