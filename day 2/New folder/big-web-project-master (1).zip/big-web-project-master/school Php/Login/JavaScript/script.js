console.log("Hello console");
let phoneNumberemailid = document.getElementById('phoneNumberemailid');
let validInvalidTxt = document.querySelector('small');
let password = document.getElementById('password');
let showPassword = document.getElementById('showPassword');
let logInbtn = document.getElementById('logInbtn');
let passwordMsg = document.getElementById('passwordMsg');

validEmailPhoneNumber = false;
validPassword = false;

phoneNumberemailid.addEventListener('focus', () => {
    let str = phoneNumberemailid.value;
    let regexEmail = /^([a-zA-Z0-9\.\-\_]+)@([a-zA-Z0-9\.\-\_]+)\.([a-zA-Z]){2,7}$/;
    let regexPhoneNumber = /^[0-9]([0-9]){9}$/;
    if (regexEmail.test(str) || regexPhoneNumber.test(str)) {
        phoneNumberemailid.style.border = "2px solid green";
        validInvalidTxt.innerHTML = "";
        validEmailPhoneNumber = true;

    }
    else {
        phoneNumberemailid.style.border = "2px solid red";

        validEmailPhoneNumber = false;
    }
})

phoneNumberemailid.addEventListener('input', () => {
    let str = phoneNumberemailid.value;
    let regexEmail = /^([a-zA-Z0-9\.\-\_]+)@([a-zA-Z0-9\.\-\_]+)\.([a-zA-Z]){2,7}$/;
    let regexPhoneNumber = /^[0-9]([0-9]){9}$/;
    if (regexEmail.test(str) || regexPhoneNumber.test(str)) {
        phoneNumberemailid.style.border = "2px solid green";
        validInvalidTxt.innerHTML = "";
        validEmailPhoneNumber = true;

    }
    else {
        phoneNumberemailid.style.border = "2px solid red";
        validEmailPhoneNumber = false;
    }
})


phoneNumberemailid.addEventListener('blur', () => {
    if (phoneNumberemailid.style.border == "2px solid green") {
        phoneNumberemailid.style.removeProperty("border");
        validEmailPhoneNumber = true;

    }
    else {
        validInvalidTxt.innerHTML = `Please enter a valid Email or Phone Number`;

    }
});

password.addEventListener('focus', () => {
    let regexPassword =/^([A-z@#$%&\^\*0-9\s]){5,20}$/;
    let str = password.value;
    if (str == "" || !(regexPassword.test(str))) {
        password.style.border = "2px solid red";
        passwordMsg.innerHTML="";
        validPassword = false;
        
    }
    else {
        password.style.border = "2px solid green";
        passwordMsg.innerHTML="";
        validPassword = true;


    }
})
password.addEventListener('input', () => {
    let regexPassword =/^([A-z@#$%&\*\^0-9\s]){5,20}$/;
    let str = password.value;
    if (str == "" || !(regexPassword.test(str))) {
        password.style.border = "2px solid red";
        passwordMsg.innerHTML="";
        validPassword = false;


        
    }
    else {
        password.style.border = "2px solid green";
        validPassword = true;
        passwordMsg.innerHTML="";


    }
})
password.addEventListener('blur', () => {
    let regexPassword =/^([A-z@#$%&\^\*0-9\s]){5,20}$/;
    let str = password.value;
    
    if (str == "" || !(regexPassword.test(str))) {
        password.style.border = "2px solid red";
        passwordMsg.innerHTML="";

        validPassword = false;
        
    }
    else {
        password.style.removeProperty("border");
        passwordMsg.innerHTML="";
        validPassword = true;
    }
});

showPassword.addEventListener('click', () => {
    if (password.type == "password") {
        password.type = "text";
    }
    else {
        password.type = "password";
    }
});

window.addEventListener('load',()=>{
    showPassword.checked=false;
})

logInbtn.addEventListener('click', (e) => {
    if (validEmailPhoneNumber && validPassword) {
        console.log("Successfully Login to your account");

    }
    else{
        if (!validEmailPhoneNumber) {
            phoneNumberemailid.style.border = "2px solid red";
            validInvalidTxt.innerHTML = `Please enter a valid Email or Phone Number`;
        }
        if (validPassword==false) {
            password.style.border = "2px solid red";
            passwordMsg.innerHTML="Please Enter Password";

        }
        e.preventDefault();

        
    }
})


