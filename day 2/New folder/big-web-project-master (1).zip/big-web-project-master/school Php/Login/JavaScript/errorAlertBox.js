setTimeout(() => {
    // Grabing alert box
 alertMsg=document.getElementById("alertMsg");
    alertMsg.style.display="none"; 
}, 5000);



let dismiss=document.getElementById('dismiss');
dismiss.addEventListener('click',(e)=>{
e.target.parentElement.style.display="none";
})