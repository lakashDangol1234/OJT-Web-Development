<?php
$accountExists=false;
$incorrectPassword=false;
// If account does not exists
if (isset($_GET['account_created']) && $_GET['account_created'] = "false") {
    $accountExists = true;
    $errorMsg = 'Account does not exists ! <a href="../Sign Up/signUp.php">Click Here</a> to sign Up';
}

if(isset($_GET['password']) && $_GET['password']=="nomatch"){
    $incorrectPassword=true;
    $errorMsg='Password do not Match ! Please Try Again.';
}


?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="Images/logo.png">
    <title>Login your Adarsha Account</title>
    <link rel="stylesheet" href="CSS/styleLogin.css">
    <?php
    if($accountExists or $incorrectPassword){
        echo '<link rel="stylesheet" href="CSS/errorAlertBox.css">'; 
    }
    ?>
</head>

<body>
    <main>
        <?php
        if($accountExists or $incorrectPassword){
             echo '<div id="alertMsg">
            <p id="msg"><b>Error!  </b>
            '.$errorMsg.'
            </p>
            <button id="dismiss">X</button>
        </div>';
            }
            ?>


        <div class="container">
            <form action="/school/partials/_handlelogin.php" method="post">
                <div class="logo">
                    <img src="Images/logo.png" alt="School Logo">
                    <h1>Login to your Account</h1>
                </div>
                <div class="inputField">
                    <label for="phoneNumberemailid">Enter your Email or Phone Number</label>
                    <input type="text" id="phoneNumberemailid" name="phoneNumberOrEmail" placeholder="Your Email or Phone Number">
                    <small></small>
                    
                </div>

      <div class="passwordField">
                    <div class="pwdInput">
                        <label for="password">Enter your Password</label>
                        <input type="password" id="password" name="password" placeholder="Your Password" >
                    </div>
                    <small id="passwordMsg"></small>
                    <div class="showpwd">
                        <input type="checkbox" name="showPassword" id="showPassword">
                        <p>Show Password</p>
                    </div>   
                    <div class="forgotPassword">
                        <a href="#">Forgot Password?</a>
                    </div>     
                </div>
               
                <button id="logInbtn">Log In</button>
            
        </div>
        </form>

        </div>
    </main>

</body>
<script src="JavaScript/script.js"></script>
<?php
if($accountExists or $incorrectPassword){
    echo '<script src="Javascript/errorAlertBox.js"></script>';
}
?>
</html>