<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adarsha Saula Yubak Secondary School</title>
    <link rel="icon" type="image/png" href="Images/logo.png">
    <link rel="stylesheet" href="../partials/_nav.css">
    <link rel="stylesheet" href="CSS/aboutUsstyle.css">
    <link rel="stylesheet" href="../partials/_footer.css">
</head>

<body>
<?php include '../partials/_nav.php' ?>
    <main>
        <div class="container">
            <div class="heading">

                <h1>Welcome To Adarsha Saula Yubak Secondary School</h1>
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quisquam, laborum?</p>
            </div>
            <div class="headingContent">
                <div class="ourStories">
                    <div class="ourStoresImg">
                        <img src="Images/stories.webp" alt="OurStories" class="headingContentImg">
                    </div>
                    <div class="ourStorestxt headingContentTxt">
                        <h1>Our Stories</h1>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Natus explicabo, corporis dicta
                            corrupti odit reprehenderit perspiciatis et harum fugiat, sint officiis .</p>
                    </div>
                </div>
                <div class="ourMission">
                    <div class="ourMissionImg">
                        <img src="Images/mission.webp" alt="OurMission" class="headingContentImg">
                    </div>
                    <div class="ourMissionTxt headingContentTxt">
                        <h1>Our Missions</h1>

                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Illum aliquid suscipit error fugiat
                            adipisci fuga tempore recusandae eveniet obcaecati. Delectus?</p>
                    </div>
                </div>
                <div class="ourVision">
                    <div class="ourVisionImg">
                        <img src="Images/vision.webp" alt="OurVision" class="headingContentImg">
                    </div>
                    <div class="OurVisionTxt headingContentTxt">
                        <h1>Our Vision</h1>
                        <p> Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, quam! Excepturi qui
                            aliquam praesentium est.</p>
                    </div>
                </div>
            </div>
            <div class="WhyChooseUs">
                <div class="WhyChooseUsTxt">
                    <h1>Why Choose Us</h1>
                    <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Omnis voluptatum amet error
                        perspiciatis iusto magni consectetur provident dolore asperiores. Amet.</p>
                </div>
                <div class="WhyChooseUsContent">
                    <div class="features">
                        <div class="Award featuresContent">
                            <small id="AwardArrow"><img src="Images/chevron_right_black_36dp.svg" alt="right_arrow"></small>
                            <h3>Award for Best School 2018</h3>
                            <p id="AwardTxt">Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi assumenda odio tempore
                                dicta mollitia.</p>
                        </div>
                        <div class="learningBest featuresContent">
                            <small id="learningBestArrow"><img src="Images/chevron_right_black_36dp.svg" alt="right_arrow"></small>
                            <h3>You're learning from the best</h3>
                            <p id="learningBestTxt">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Minima provident modi illum
                                nihil ipsa.</p>
                        </div>
                        <div class="Ourdegrees featuresContent">
                            <small id="OurdegreesArrow"><img src="Images/chevron_right_black_36dp.svg" alt="right_arrow"></small>
                            <h3>Our degrees are recognized worldwide</h3>
                            <p id="OurdegreesTxt">Lorem ipsum dolor sit amet consectetur adipisicing elit. Placeat nemo aspernatur
                                consectetur nisi minima!</p>
                        </div>
                        <div class="encourage featuresContent">
                            <small id="encourageArrow"><img src="Images/chevron_right_black_36dp.svg" alt="right_arrow"></small>
                            <h3>We encourage our students to go global</h3>
                            <p id="encourageTxt">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Vitae, ratione error. Aut, quae
                                sunt!</p>
                        </div>
                    </div>
                    <div class="sampleVideo">
                        <video controls>
                            <source src="Video/SampleVideo.mp4" type="video/mp4">
                        </video>
                    </div>
             </div>
            </div>
        <?php include '../partials/_footer.php' ?>
           
</body>
<script src="JavaScript/script.js"></script>

</html>