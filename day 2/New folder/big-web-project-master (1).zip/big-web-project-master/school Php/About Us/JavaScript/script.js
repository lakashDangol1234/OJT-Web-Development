// Giving id of activeNavBar to about so that it can be highlighted in the nav bar
let about=document.getElementsByClassName('navMenu')[1];
about.firstChild.id='activeNavBar';



let Award = document.querySelector('.Award');
let AwardArrow=document.getElementById('AwardArrow');
let learningBestArrow = document.getElementById('learningBestArrow');
let OurdegreesArrow = document.getElementById('OurdegreesArrow');
let encourageArrow = document.getElementById('encourageArrow');
let learningBest = document.querySelector('.learningBest');
let Ourdegrees = document.querySelector('.Ourdegrees');
let encourage = document.querySelector('.encourage');
let AwardTxt = document.getElementById('AwardTxt');
let learningBestTxt = document.getElementById('learningBestTxt');
let OurdegreesTxt = document.getElementById('OurdegreesTxt');
let encourageTxt = document.getElementById('encourageTxt');

Award.addEventListener('click',()=>{
    if (AwardTxt.style.display=='none') {
        AwardTxt.style.display='block';
        AwardArrow.innerHTML=`<img src="Images/expand_more_black_36dp.svg" alt="down_arrow">`;
    }
    else{
        AwardTxt.style.display='none';
        AwardArrow.innerHTML=`<img src="Images/chevron_right_black_36dp.svg" alt="right_arrow">`;
    }
});
learningBest.addEventListener('click',()=>{
    if (learningBestTxt.style.display=='none') {
        learningBestTxt.style.display='block';
        learningBestArrow.innerHTML=`<img src="Images/expand_more_black_36dp.svg" alt="down_arrow">`;
    }
    else{
        learningBestTxt.style.display='none';
        learningBestArrow.innerHTML=`<img src="Images/chevron_right_black_36dp.svg" alt="right_arrow">`;
    }
});
Ourdegrees.addEventListener('click',()=>{
    if (OurdegreesTxt.style.display=='none') {
        OurdegreesTxt.style.display='block';
        OurdegreesArrow.innerHTML=`<img src="Images/expand_more_black_36dp.svg" alt="down_arrow">`;
    }
    else{
        OurdegreesTxt.style.display='none';
        OurdegreesArrow.innerHTML=`<img src="Images/chevron_right_black_36dp.svg" alt="right_arrow">`;
    }
})
encourage.addEventListener('click',()=>{
    if (encourageTxt.style.display=='none') {
        encourageTxt.style.display='block';
        encourageArrow.innerHTML=`<img src="Images/expand_more_black_36dp.svg" alt="down_arrow">`;
    }
    else{
        encourageTxt.style.display='none';
        encourageArrow.innerHTML=`<img src="Images/chevron_right_black_36dp.svg" alt="right_arrow">`;
    }
})
