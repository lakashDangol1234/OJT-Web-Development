<?php
$error=false;
// Handeling error
if (isset($_GET['error'])) {
    $ErrorMsg = "Error! ";
    $error = true;
    $includeAlertMsgJs = true;
    if ($_GET['error'] == "phoneNumberAlreadyExists") {
        $errorMsg = "Phone Number Already Exists . Please Enter another Phone Number";
    }
    if ($_GET['error'] == "emailAlreadyExists") {
        $errorMsg = "Email Already Exists . Please Enter correct Email";
    }


    // Password no match will not happen because javascript will handle it
    if ($_GET['error'] == "passwordNoMatch") {
        $errorMsg = "Your Password do not match!";
    }
}
?>




<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="Images/logo.png">
    <title>Create your Adarsha Account</title>
    <link rel="stylesheet" href="CSS/styleSignUp.css">
    
    <?php
    if($error){
    echo '<link rel="stylesheet" href="CSS/errorAlertBox.css">';
    }
    ?>
</head>

<body>
    <main>
    <?php
        if($error){    
            echo '<div id="alertMsg">
            <p id="msg"><b>'. $ErrorMsg .'</b>
                    '. $errorMsg.'
                </p>
                <button id="dismiss">X</button>
                </div>';
                }
                ?>
        <div class="container">
            <form action="/school/partials/_handleSignUp.php" method="post">
                <div class="logo">
                    <img src="Images/logo.png" alt="School Logo">
                    <h1>Create a New Account</h1>
                </div>
                <div class="inputField">
                    <label for="firstName">Enter your First Name</label>
                    <input type="text" id="firstName" name="firstName" placeholder="Your First Name">
                    <label for="lastName">Enter your Last name</label>

                    <input type="text" id="lastName" name="lastName" placeholder="Your Last Name"><br>
                    <label for="emailid">Enter your Email</label>

                    <input type="email" id="emailid" name="email" placeholder="Your Email address">
                    <label for="phoneNumber">Enter your Phone Number</label>
                    <input type="text" id="phoneNumber" name="phoneNumber" placeholder="Your Phone Number">
                    <label for="address">Enter your Address</label>
                    <input type="text" id="address" name="address" placeholder="Your Address">
                    <label for=""></label>
                </div>
                <div class="radioSelection">
                    <h2>Select your gender :</h2>
                    <div class="genderSelection">
                        <span class="for-male">
                            <input type="radio" id="male" name="gender" value="male">
                            <label for="male">Male</label>
                        </span>
                        <span class="for-female">
                            <input type="radio" id="female" name="gender" value="female">
                            <label for="female">Female</label>
                        </span>
                        <span class="for-other">
                            <input type="radio" id="other" name="gender" value="other">
                            <label for="other">Other</label>
                        </span>
                    </div>
                </div>

                <div class="birthdateInput">
                    <h2>Enter your birthday</h2>
                    <div class="birthday">
                        <div class="birthElement">
                            <label for="birthMonth">Month</label>
                            <select name="birthMonth" id="birthMonth">
                                <option value="1">January</option>
                                <option value="2">February</option>
                                <option value="3">March</option>
                                <option value="4">April</option>
                                <option value="5">May</option>
                                <option value="6">June</option>
                                <option value="7">July</option>
                                <option value="8">August</option>
                                <option value="9">September</option>
                                <option value="10">October</option>
                                <option value="11">November</option>
                                <option value="12">December</option>
                            </select>
                        </div>
                        <div class="birthElement">
                            <label for="birthDay">Day</label>
                            <input type="text" pattern="([0-9]){0,2}" placeholder="Day" id="birthDay" name="birthDay">
                        </div>
                        <div class="birthElement">
                            <label for="birthYear">Year</label>
                            <input type="text" pattern="([0-9]){0,4}" id="birthYear" name="birthYear" placeholder="Year">
                        </div>
                    </div>
                </div>
                =
                <div class="passwordField">
                    <div class="pwdInput">
                        <label for="newPassword">Enter your New Password</label>
                        <input type="password" id="newPassword" placeholder="New Password" name="password">
                    </div>
                    <div class="showpwd">
                        <input type="checkbox" name="showPassword" id="showPassword">
                        <p>Show Password</p>
                    </div>
                    <div class="pwdInput">
                        <label for="reTypePassword">Confirm your Password</label>
                        <input type="password" id="reTypePassword" name="cpassword" placeholder="Confirm Password">
                    </div>
                    <div class="showpwd">
                        <input type="checkbox" name="showPassword" id="confirmShowpassword">
                        <p>Show Password</p>
                    </div>
                </div>
                <button id="signUpbtn">Sign Up</button>
        </div>
        </form>

        </div>
    </main>

</body>
<script src="JavaScript/signUp.js"></script>
<?php
    if($error){
        echo '<script src="Javascript/errorAlertBox.js"></script>';
    }
?>

</html>