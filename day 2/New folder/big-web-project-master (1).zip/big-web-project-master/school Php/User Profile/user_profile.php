<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../partials/_nav.css">
    <link rel="stylesheet" href="CSS/user_profile.css">
    <link rel="icon" type="image/png" href="Images/logo.png">

    <!-- dynamically displaying title using javascript -->
    <title></title>

</head>

<body>
    <?php include '../partials/_nav.php' ?>
    <main>
     
        <div class="container">
            <h1>Your Profile</h1>
            <img src="../user_default_img.png" alt="User_profile" width="200px;" draggable="true">
            <?php
            $user_id = $_SESSION['user_id'];
            include '../partials/_dbconnect.php';
            $sql = "SELECT * from `users` where `user_id`='$user_id'";
            $result = mysqli_query($conn, $sql);
            while ($row = mysqli_fetch_assoc($result)) {
                $username = $row['first_name'] . " " . $row['last_name'];
                $email = $row['email'];
                $phone_number = $row['phone_number'];
                $address = $row['address'];
                $gender = $row['gender'];
                $birth_date = $row['birth_date'];
            }
            ?>
            <div class="info">
                <?php
                echo '<hr>
            <p>Name: <em>' . $username . '</em></p>
            <hr>
            <p>Email: <em>' . $email . '</em></p>
            <hr>
            <p>Phone Number: <em>' . $phone_number . '</em></p>
            <hr>
            <p>Address: <em>' . $address . '</em></p>
            <hr>
            <p>Gender: <em>' . $gender . '</em></p>
            <hr>
            <p>Birth Date: <em>' . $birth_date . '</em></p>
            <hr>
            <div class="moreSettings">
                <button onclick="window.location=\'/school/User Profile/More Settings/moreSettings.php\'">More Settings</button>
            </div>';
                ?>
            </div>
        </div>
    </main>
    <?php
    // Transfering the username to the hidden input tag to show the title dynamically by javascript
    echo '<input type="hidden" name="username" id="username" value="'.$_SESSION['user_name'].'">'
    ?>
</body>

</html>


<script>
    // for adding active state to the profile on the nav bar
    let user_profile = document.getElementById('user');
    user_profile.classList = "userActive";

    // Adding title in the browser of username
    let username=document.getElementById('username').value;
    let title=document.querySelector('title');
    title.innerHTML=username;
</script>