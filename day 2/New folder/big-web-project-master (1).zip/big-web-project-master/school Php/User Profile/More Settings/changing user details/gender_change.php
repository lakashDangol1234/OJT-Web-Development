<?php

$error=false;
$str="";


// If the password do not match
if (isset($_GET['incorrectPassword']) && $_GET['incorrectPassword'] == "true") {
    $error=true;
    $str = "Incorrect Password";
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/font.css">
    <link rel="icon" type="image/png" href="Images/logo.png">
    <title>Change Email</title>
    
    <?php
    if($error){
    echo '<link rel="stylesheet" href="CSS/alertMsg_detailChange.css">';
    }
    ?>
    <link rel="stylesheet" href="CSS/detail_change_style.css">
</head>

<body>
<?php
        if ($error) {
            echo '<div id="alertMsg">
           <p id="msg"><b>Error! </b>';
            echo $str;
            echo '</p>
            <button id="dismiss">X</button>
        </div>';
        }
        ?>
    <main class="mainContainer">
        <div class="container" style="width:60vw;">
            <h3 class="heading">Change Your Name</h3>
            <form action="/school/partials/_handleInfoChange.php?changeGender=true" method="post">
                <h2 class="txt" style="display:inline; margin-right:5%;">Select your gender :</h2>
                <input type="radio" id="male" name="gender" value="male" checked>
                <label for="male" class="marginRight-3">Male</label>

                <input type="radio" id="female" name="gender" value="female">
                <label for="female" class="marginRight-3">Female</label>

                <input type="radio" id="other" name="gender" value="other">
                <label for="other" class="marginRight-3">Other</label>
                <br>
                <br>

                <br>
                <label for="password">Password :</label>
                <input type="password" id="password" name="password">
                <div class="showpwd">
                    <input type="checkbox" name="showPassword" id="showPassword">
                    <p class="marginLeft-1">Show Password</p>
                </div>
                <button class="btn">Change Gender</button>
            </form>

        </div>

        </div>
    </main>
</body>
<script src="JavaScript/showPasswordFunctionality.js"></script>
<script src="JavaScript/form_validation.js"></script>
<?php
if($error){
    echo '<script src="JavaScript/AlertMsgBox_change_details.js"></script>';
}
?>
</html>