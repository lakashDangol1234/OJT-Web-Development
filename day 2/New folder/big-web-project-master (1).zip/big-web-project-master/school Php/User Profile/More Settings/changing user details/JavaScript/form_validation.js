let validFirstName=false;
let validLastName=false;
let validEmail=false;
let validPhoneNumber=false;
let validAddress=false;
let validBirthDay=false;
let validBirthYear=false;



// Grabing password elements
// let password=document.getElementById('password');


// For password input tag || password id is already grabbed by the file 'showPasswordFunctionality.js'
if(password!=null){
    password.addEventListener('blur', () => {
        let str = password.value;
        let regexPassword =/^([A-z@#$%&\^\*0-9\s]){5,10}$/;
    
        
        if (regexPassword.test(str)) {
            password.style.border = "2px solid green";
            validCurrentPassword = true;
        }
        else {
            password.style.border="2px solid red";
            validCurrentPassword = false;
        }
    });
}


// For name change
let fname=document.getElementById('fname');
let lname=document.getElementById('lname');
if(fname!=null && lname!=null){

    fname.addEventListener('blur',()=>{
        let str=fname.value;
        let regexfirstName=/^[A-Za-z]([A-Za-z]){1,20}$/;
        if (regexfirstName.test(str)) {
            fname.style.border="2px solid green";
            validFirstName = true;
            
        }
        else{
            fname.style.border="2px solid red";
            validFirstName = false;
        }
    })
    lname.addEventListener('blur',()=>{
        let str=lname.value;
        let regexlastName=/^[A-Za-z]([A-Za-z]){1,20}$/;
        if (regexlastName.test(str)) {
            lname.style.border="2px solid green";
            validLastName = true;
            
        }
        else{
            lname.style.border="2px solid red";
            validLastName = false;
        }
    })
}



// For Emali
let email= document.getElementById('email');
if(email!=null){
    email.addEventListener('blur',()=>{
        let str=email.value;
        let regexemail=/^([a-zA-Z0-9\.\-\_]+)@([a-zA-Z0-9\.\-\_]+)\.([a-zA-Z]){2,7}$/;
        if (regexemail.test(str)) {
            email.style.border="2px solid green";
            validEmail= true;
            
        }
        else{
            email.style.border="2px solid red";
            validEmail= false;
        }
    })
    

}



// For Phone Number 
let phone_number=document.getElementById('phone_number');
if(phone_number!=null){
    phone_number.addEventListener('blur',()=>{
        let str=phone_number.value;
        let regexphoneNumber=/^[0-9]([0-9]){9}$/;
        if (regexphoneNumber.test(str)) {
            
            phone_number.style.border="2px solid green";
            validPhoneNumber = true;
            
        }
        else{
            
            phone_number.style.border="2px solid red";
            validPhoneNumber = false;
        }
    })
}

// For Address
let address=document.getElementById('address');
if(address!=null){
    address.addEventListener('blur',()=>{
        let str=address.value;
        let regexaddress=/^[A-Za-z]([A-Za-z\,\s]){1,30}$/;
        if (regexaddress.test(str)) {
            
            address.style.border="2px solid green";
            validAddress = true;
            
        }
        else{
            
            address.style.border="2px solid red";
            validAddress = false;
        }
    })
}

// For Birth Date
let birthMonth=document.getElementById('birthMonth');
let birthDay=document.getElementById('birthDay');
let birthYear=document.getElementById('birthYear');

if(birthMonth!=null && birthDay!=null && birthYear!=null){
    birthDay.addEventListener('blur',()=>{
        let str=birthDay.value;
        let regexbirthDay=/^[0-9]([0-9]){0,1}$/;
        if (regexbirthDay.test(str) && str<32) {
            
            birthDay.style.border="2px solid green";
            validBirthDay = true;
            
        }
        else{
            
            birthDay.style.border="2px solid red";
            validBirthDay = false;
        }
    })
    birthYear.addEventListener('blur',()=>{
        let str=birthYear.value;
        let regexbirthYear=/^[0-9]([0-9]){1,3}$/;
        let currentDate=new Date();
        let currentYear=currentDate.getFullYear();
    
        if (regexbirthYear.test(str) && str<=currentYear) {
            
            birthYear.style.border="2px solid green";
            validBirthYear=true;
            
        }
        else{
            
            birthYear.style.border="2px solid red";
            validBirthYear=false;
        }
    });
}