// Grabing password input tag elements
let currentPassword=document.getElementById('current_password');
let newPassword=document.getElementById('new_password');
let confirmPassword=document.getElementById('confirm_new_password');

// Grabing show password check box
let showCurrentPassword = document.getElementById('showCurrentPassword');
let showNewPassword = document.getElementById('showNewPassword');
let showConfirmPassword = document.getElementById('showConfirmPassword');



// Making show password functionality
showCurrentPassword.addEventListener('click', () => {
    if (currentPassword.type == "password") {
        currentPassword.type = "text";
    }
    else {
        currentPassword.type = "password";
    }
});

showNewPassword.addEventListener('click', () => {
    if (newPassword.type == "password") {
        newPassword.type = "text";
    }
    else {
        newPassword.type = "password";
    }
});

confirmPassword.addEventListener('click', () => {
    if (confirmPassword.type == "password") {
        confirmPassword.type = "text";
    }
    else {
        confirmPassword.type = "password";
    }
});


window.addEventListener('load',()=>{
    showCurrentPassword.checked=false;
    showNewPassword.checked=false;
    showConfirmPassword.checked=false;
})