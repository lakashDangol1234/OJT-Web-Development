<?php

$error=false;
$str="";


// If the password do not match
if (isset($_GET['incorrectPassword']) && $_GET['incorrectPassword'] == "true") {
    $error=true;
    $str = "Incorrect Password";
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/font.css">
    <link rel="icon" type="image/png" href="Images/logo.png">

    <?php
    if($error){
    echo '<link rel="stylesheet" href="CSS/alertMsg_detailChange.css">';
    }
    ?>
    <link rel="stylesheet" href="CSS/detail_change_style.css">
    <title>Change Name</title>
</head>

<body>
<?php
        if ($error) {
            echo '<div id="alertMsg">
           <p id="msg"><b>Error! </b>';
            echo $str;
            echo '</p>
            <button id="dismiss">X</button>
        </div>';
        }
        ?>
    <main class="mainContainer">
        <div class="container">
            <h3 class="heading">Change Your Birth Date</h3>
            <form action="/school/partials/_handleInfoChange.php?changeBirthDate=true" method="post">
                <div class="birthday">
                    <div class="birthElement">
                        <label for="birthMonth" class="marginRight-2">Month</label>
                        <select name="birthMonth" id="birthMonth">
                            <option value="1">January</option>
                            <option value="2">February</option>
                            <option value="3">March</option>
                            <option value="4">April</option>
                            <option value="5">May</option>
                            <option value="6">June</option>
                            <option value="7">July</option>
                            <option value="8">August</option>
                            <option value="9">September</option>
                            <option value="10">October</option>
                            <option value="11">November</option>
                            <option value="12">December</option>
                        </select>
                    </div>
                    <div class="birthElement">
                        <label for="birthDay" class="marginRight-2">Day</label>
                        <input type="text" pattern="([0-9]){0,2}" placeholder="Day" id="birthDay" name="birthDay">
                    </div>
                    <div class="birthElement">
                        <label for="birthYear" class="marginRight-2">Year</label>
                        <input type="text" pattern="([0-9]){0,4}" id="birthYear" name="birthYear" placeholder="Year">
                    </div>
                </div>
                <br>
                <label for="password">Password :</label>
                <input type="password" id="password" name="password">
                <br>
                <div class="showpwd">
                    <input type="checkbox" name="showPassword" id="showPassword">
                    <p class="marginLeft-1">Show Password</p>
                </div>
                <button class="btn">Change Birth Date</button>
            </form>
        </div>
    </main>
</body>
<script src="JavaScript/showPasswordFunctionality.js"></script>
<script src="JavaScript/form_validation.js"></script>
<?php
if($error){
    echo '<script src="JavaScript/AlertMsgBox_change_details.js"></script>';
}
?>
</html>