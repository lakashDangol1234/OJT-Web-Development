let validCurrentPassword=false;
let validNewPassword=false;
let validConfirmPassword=false;


// For Password Change

// currentPassword / newPassword / confirmPassword are already declared in file named 'change_password_showPasswordFunctionality.js'

/*
let currentPassword=document.getElementById('current_password');
let newPassword=document.getElementById('new_password');
let confirmPassword=document.getElementById('confirm_new_password');
*/

if(currentPassword!=null && newPassword!=null && confirmPassword!=null){
    currentPassword.addEventListener('blur', () => {
        let str = currentPassword.value;
        let regexPassword =/^([A-z@#$%&\^\*0-9\s]){5,20}$/;
    
        
        if (regexPassword.test(str)) {
            currentPassword.style.border = "2px solid green";
            validCurrentPassword = true;
        }
        else {
            currentPassword.style.border="2px solid red";
            validCurrentPassword = false;
        }
    });
    newPassword.addEventListener('blur', () => {
        let str = newPassword.value;
        let regexPassword =/^([A-z@#$%&\^\*0-9\s]){5,20}$/;
    
        
        if (regexPassword.test(str)) {
            newPassword.style.border = "2px solid green";
            validNewPassword = true;
        }
        else {
            newPassword.style.border="2px solid red";
            validNewPassword = false;
        }
    });
    confirmPassword.addEventListener('blur', () => {
        let str = confirmPassword.value;
        let regexPassword =/^([A-z@#$%&\^\*0-9\s]){5,20}$/;
    
        
        if (regexPassword.test(str) && str==newPassword.value) {
            confirmPassword.style.border = "2px solid green";
            validConfirmPassword = true;
        }
        else {
            confirmPassword.style.border="2px solid red";
            validConfirmPassword = false;
        }
    });
    
}

