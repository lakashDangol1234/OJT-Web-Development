<?php

$error = false;
$str = "";


// If the password is incorrect
if (isset($_GET['incorrectPassword']) && $_GET['incorrectPassword'] == "true") {
    $error = true;
    $str = "Incorrect Password";
}

// If the new password do not match with confirm password
if (isset($_GET['passwordDonotMatch']) && $_GET['passwordDonotMatch'] == "true") {
    $error = true;
    $str = "New Password does not match with confirm password";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/font.css">
    <link rel="icon" type="image/png" href="Images/logo.png">
    <?php
    if ($error) {
        echo '<link rel="stylesheet" href="CSS/alertMsg_detailChange.css">';
    }
    ?>
    <link rel="stylesheet" href="CSS/detail_change_style.css">
    <title>Change Password</title>
</head>

<body>
    <?php
    if ($error) {
        echo '<div id="alertMsg">
           <p id="msg"><b>Error! </b>';
        echo $str;
        echo '</p>
            <button id="dismiss">X</button>
        </div>';
    }
    ?>
    <main class="mainContainer">
        <div class="container" style="height:265px;">
            <h3 class="heading">Change Your Password</h3>
            <form action="/school/partials/_handleInfoChange.php?changePassword=true" method="post">
                <!-- Current Password  -->
                <label for="current_password">Current Password :</label>
                <input type="password" id="current_password" name="current_password">
                <div class="showpwd" style="margin-left:190px;">
                    <input type="checkbox" name="showCurrentPassword" id="showCurrentPassword">
                    <p class="marginLeft-1">Show Password</p>
                </div>
                <br>

                <!-- New Password  -->
                <label for="new_password">New Password :</label>
                <input type="password" id="new_password" name="new_password">
                <div class="showpwd" style="margin-left:160px;">
                    <input type="checkbox" name="showNewPassword" id="showNewPassword">
                    <p class="marginLeft-1">Show Password</p>
                </div>
                <br>

                <!-- Confirm Password  -->
                <label for="confirm_new_password">Confirm New Password :</label>
                <input type="password" id="confirm_new_password" name="confirm_new_password">
                <div class="showpwd" style="margin-left:245px;">
                    <input type="checkbox" name="showConfirmPassword" id="showConfirmPassword">
                    <p class="marginLeft-1">Show Password</p>
                </div>
                <br>

                <button class="btn">Change Password</button>
            </form>
        </div>
    </main>
</body>
<script src="JavaScript/change_password_showPasswordFunctionality.js"></script>
<script src="JavaScript/form_validation_change_password.js"></script>
<?php
if ($error) {
    echo '<script src="JavaScript/AlertMsgBox_change_details.js"></script>';
}
?>

</html>