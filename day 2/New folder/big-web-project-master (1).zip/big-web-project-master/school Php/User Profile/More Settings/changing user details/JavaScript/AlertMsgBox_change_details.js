// Removing the get request parameter of the url
let currentUrl = window.location.toString();
let questionMarkIndex = currentUrl.lastIndexOf("?");
let str='3';
let currentUrl_Without_Get_Request = currentUrl.slice(0, questionMarkIndex);

// Adding event listener to the dismiss button of alertBox
let dismissBtn = document.getElementById('dismiss');
dismissBtn.addEventListener('click', (e) => {
    e.target.parentElement.remove();
    window.location = currentUrl_Without_Get_Request;

})

//  Removing the alert message box after 5 seconds 
setTimeout(() => {
    let alertBox = document.getElementById('alertMsg');
    alertBox.remove();
    window.location = currentUrl_Without_Get_Request;
}, 5000)