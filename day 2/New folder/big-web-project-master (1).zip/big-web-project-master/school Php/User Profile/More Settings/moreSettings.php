<?php
session_start();
            $user_id = $_SESSION['user_id'];
            include '../../partials/_dbconnect.php';
            $sql = "SELECT * from `users` where `user_id`='$user_id'";
            $result = mysqli_query($conn, $sql);
            while ($row = mysqli_fetch_assoc($result)) {
                $username = $row['first_name'] . " " . $row['last_name'];
                $email = $row['email'];
                $phone_number = $row['phone_number'];
                $address = $row['address'];
                $gender = $row['gender'];
                $birth_date = $row['birth_date'];
            }
            
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/moreSettings.css">
    <link rel="stylesheet" href="/partials/_nav.css">
    <title>More Settings</title>
</head>

<body>
    <main>

        <div class="container">

            <!-- heading  -->
            <div class="heading">
                <!-- user_img  -->
                <img src="Images/settings.png" alt="More settings">
                <h3 style="display: inline-block;">More Settings</h3>
            </div>

            <!-- Name  -->
            <p><em>Current Name: </em><?php echo $username ?><a href="./changing user details/name_change.php">Change Name</a>
            </p>

            <!-- Email  -->
            <p><em>Current Email: </em><?php echo $email ?><a href="./changing user details/email_change.php">Change
                    Email</a></p>

            <!-- Phone Number  -->
            <p><em>Current Phone Number:</em><?php echo $phone_number ?><a href="./changing user details/phoneNumber_change.php">Change Phone Number</a></p>

            <!-- Address  -->
            <p><em>Current Address: </em><?php echo $address ?><a href="./changing user details/address_change.php">Change Address</a>
            </p>

            <!-- Gender  -->
            <p><em>Current Gender: </em><?php echo $gender ?><a href="./changing user details/gender_change.php">Change gender</a></p>

            <!-- BirthDate  -->
            <p><em>Current Birth Date: </em><?php echo $birth_date ?><a href="./changing user details/birthDate_change.php">Change Birth Date</a></p>

            <!-- Password  -->
            <p><a href="./changing user details/password_change.php">Change Password</a></p>
        </div>
    </main>
</body>

</html>