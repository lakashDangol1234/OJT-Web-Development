// Adding event listener to the dismiss button of alertBox
let dismissBtn=document.getElementById('dismiss');
dismissBtn.addEventListener('click',(e)=>{
    e.target.parentElement.remove();
    window.location="/school/Contact/contact.php";
})

 // Removing the alert message box after 5 seconds 
 setTimeout(()=>{
    let alertBox=document.getElementById('alertMsg');
    alertBox.remove();
    window.location="/school/Contact/contact.php";
},5000)
