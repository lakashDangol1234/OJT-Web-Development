<?php
$success = false;
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    if (isset($_GET['submission']) && $_GET['submission'] == "success") {
        $success = true;
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adarsha Saula Yubak Secondary School</title>
    <link rel="icon" type="image/png" href="Images/logo.png">
    <link rel="stylesheet" href="../partials/_nav.css">
    <link rel="stylesheet" href="CSS/contactStyle.css">
    <link rel="stylesheet" href="CSS/alertMsg.css">
    <link rel="stylesheet" href="../partials/_footer.css">
</head>

<body>
    <?php include '../partials/_nav.php' ?>
    <main>
    <?php
        if ($success) {
            echo '<div id="alertMsg">
           <p id="msg"><b>Success! </b>
            Your request has been successfully submitted</p>
            <button id="dismiss">X</button>
        </div>';
        }
        ?>
        <div class="container">
        <div class="formContainer">
            <form action="/school/partials/_handleContact.php" method="post">
                <h1>Contact Form</h1>
                <label for="name">Your Name</label>
                <input type="text" id="name" name="name" placeholder="Enter your Name">
                <small class="validTxt" id="nameValid"></small>
                <label for="email">Your Email</label>
                <input type="email" id="email" name="email" placeholder="Enter your Email">
                <small class="validTxt" id="emailValid"></small>

                <label for="phoneNumber">Your Phone Number</label>
                <input type="text" id="phoneNumber" name="phoneNumber" placeholder="Enter your Phone Number">
                <small class="validTxt" id="phonenumberValid"></small>

                <label for="message">Enter your message</label>
                <textarea name="message" id="message" cols="30" rows="10" placeholder="Your message"></textarea>
                <button id="submitBtn">Submit</button>
            </form>
        </div>
        <?php include '../partials/_footer.php' ?>
</body>
<script src="JavaScript/index.js"></script>
<?php
if($success){
    echo '<script src="JavaScript/successAlertMsgBox.js"></script>';
}
?>
</html>