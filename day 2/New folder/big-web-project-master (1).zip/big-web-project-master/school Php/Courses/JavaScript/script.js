// Giving id of activeNavBar to Courses so that it can be highlighted in the nav bar
let courses=document.getElementsByClassName('navMenu')[2];
courses.firstChild.id='activeNavBar';
