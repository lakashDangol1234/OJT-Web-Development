<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adarsha Saula Yubak Secondary School</title>
    <link rel="icon" type="image/png" href="Images/logo.png">
    <link rel="stylesheet" href="../partials/_nav.css">
    <link rel="stylesheet" href="CSS/coursesStyle.css">
    <link rel="stylesheet" href="../partials/_footer.css">
</head>

<body>
    <?php include '../partials/_nav.php' ?> 
    <main>
        <!-- Search Top Bar  -->
        <div id="searchCourses">
            <input type="text" id="search" name="search" placeholder="Search Courses">
            <select name="category" id="category">
                <option value="All Category">All Category</option>
                <option value="1Category">Category</option>
                <option value="2Category">Category</option>
            </select>
            <button id="searchNowBtn">Search Now</button>
        </div>
        <div class="main-container">
            <div id="categories">
                <!-- Pull the card from the database and use for loop -->
                <!-- Course Cards here -->
                <div class="cards">
                    <img src="Images/course-1.webp" alt="">
                    <div class="description">
                        <h2>Software Training</h2>
                        <h3>Mr.John Taylor</h3>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Harum, unde!</p>
                        <hr>
                        <div class="courseFeature">
                            <p>20 Students</p>
                            <p>5 Ratings</p>
                            <p><b>$130</b></p>
                        </div>
                    </div>
                </div>
                <div class="cards">
                    <img src="Images/course-2.webp" alt="">
                    <div class="description">
                        <h2>Developing Mobile Apps</h2>
                        <h3>Mr.Lucius</h3>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Harum, unde!</p>
                        <hr>
                        <div class="courseFeature">
                            <p>20 Students</p>
                            <p>5 Ratings</p>
                            <p><b>Free</b></p>
                        </div>
                    </div>
                </div>
                <div class="cards">
                    <img src="Images/course-3.webp" alt="">
                    <div class="description">
                        <h2>Starting a Startup</h2>
                        <h3>Mr.Charles</h3>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Harum, unde!</p>
                        <hr>
                        <div class="courseFeature">
                            <p>20 Students</p>
                            <p>5 Ratings</p>
                            <p><b>$220</b></p>
                        </div>
                    </div>
                </div>
                <div class="cards">
                    <img src="Images/course-4.webp" alt="">
                    <div class="description">
                        <h2>Learn Basic Gername Fast</h2>
                        <h3>Mr.John Taylor</h3>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Harum, unde!</p>
                        <hr>
                        <div class="courseFeature">
                            <p>20 Students</p>
                            <p>5 Ratings</p>
                            <p><b>$130</b></p>
                        </div>
                    </div>
                </div>
                <div class="cards">
                    <img src="Images/course-5.webp" alt="">
                    <div class="description">
                        <h2>Business Groud Up</h2>
                        <h3>Mr.Lucius</h3>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Harum, unde!</p>
                        <hr>
                        <div class="courseFeature">
                            <p>20 Students</p>
                            <p>5 Ratings</p>
                            <p><b>Free</b></p>
                        </div>
                    </div>
                </div>
                <div class="cards">
                    <img src="Images/course-6.webp" alt="">
                    <div class="description">
                        <h2>Java Technology</h2>
                        <h3>Mr.Charles</h3>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Harum, unde!</p>
                        <hr>
                        <div class="courseFeature">
                            <p>20 Students</p>
                            <p>5 Ratings</p>
                            <p><b>$220</b></p>
                        </div>
                    </div>
                </div>
            </div>
            <div id="sidebar">
                <!-- Categories List Here -->
                <div class="categoriesList">
                    <h1>Categories</h1>
                    <p>&gt; Art & Design</p>
                    <p>&gt; Business</p>
                    <p>&gt; IT & Software</p>
                    <p>&gt; Languages</p>
                    <p>&gt; Programming</p>
                    <!-- Categories List Ends Here -->
                </div>

                <!-- Latest Course Here -->
                <div class="latestCourse">
                    <h1>Latest Course</h1>
                    <div class="latestCourse-card">
                        <img src="Images/latest_1.webp" alt="">
                        <p>How to Design a Logo a Beginners Course<br>
                            <b>Free</b>
                        </p>
                    </div>


                    <div class="latestCourse-card">
                        <img src="Images/latest_2.webp" alt="">
                        <p>How to Design a Logo a Beginners Course<br>
                            <b>Free</b>
                        </p>
                    </div>
                    <div class="latestCourse-card">
                        <img src="Images/latest_3.webp" alt="">
                        <p>How to Design a Logo a Beginners Course<br>
                            <b>Free</b>
                        </p>
                    </div>
                    <!-- Latest Course Ends Here -->
                </div>

                <!-- instagram Starts here -->
                <div class="instagram">
                    <h1>Instagram</h1>
                    <img src="Images/instagram-1.webp" alt="">
                    <img src="Images/instagram-2.webp" alt="">
                    <img src="Images/instagram-3.webp" alt="">
                    <img src="Images/instagram-4.webp" alt="">
                    <img src="Images/instagram-5.webp" alt="">
                    <img src="Images/instagram-6.webp" alt="">
                    <!-- instagram Ends Here -->
                </div>
                <div class="tags">
                    <h1>Tags</h1>
                    <button class="btn-tags">CREATIVE</button>
                    <button class="btn-tags">UNIQUE</button>
                    <button class="btn-tags">PHOTOGRAPHY</button>
                    <button class="btn-tags">IDEAS</button>
                    <button class="btn-tags">WORDPRESS</button>
                    <button class="btn-tags">STARTUP</button>
                </div>
                <!-- tags Ends Here -->
                <div class="freeBook">
                    <p>Free Book</p>
                    <button>Download Now</button>
                </div>
            </div>
</div>
<div class="container">
        <?php include '../partials/_footer.php' ?>


</body>
<script src="JavaScript/script.js"></script>



</html>