<?php
session_start();
echo '<header>
        <nav>
            <div class="logo">
                <a href="/school/Home/index.php">
                <img src="Images/logo.png" alt="Logo">
            </a>
            </div>
            <ul>
                <li class="navMenu"><a href="/school/Home/index.php">Home</a></li>
                <li class="navMenu"><a href="/school/About Us/aboutUs.php">About</a></li>
                <li class="navMenu"><a href="/school/Courses/courses.php">Courses</a></li>
                <li class="navMenu"><a href="/school/Home/">Research</a></li>
                <li class="navMenu"><a href="/school/Home/">News</a></li>
                <li class="navMenu"><a href="/school/Contact/contact.php">Contact Us</a></li>
            </ul>
            <div class="search">
                <input type="text" placeholder="Search Here">
                <button id="searchBtn">Search</button>
            </div>';
            if(isset($_SESSION['created_account']) && $_SESSION['created_account']==true && isset($_SESSION['user_id']) && isset($_SESSION['user_name'])){
                echo '<div class="loginSignUp">
                <div id="user" onclick="location=\'/school/User Profile/user_profile.php\'">
                <img src="../user_default_img.png" alt="user_default_img" width="50px">
                <p>'.$_SESSION['user_fname'].'</p>
                </div>
                <button><a href="/school/partials/logout.php">Log out</a></button>
                </div>
                ';
            }
            else{
          
                echo '<div class="loginSignUp">
                <button><a href="../Login/login.php">Login</a></button>
                <button><a href="../Sign Up/signUp.php">Sign Up</a></button>
                </div>';
            }
            echo'
                </nav>
       
    </header>';
?>
