<?php
if($_SERVER['REQUEST_METHOD']=='POST'){
    include '_dbconnect.php';
    $fname=$_POST['firstName'];
    $lname=$_POST['lastName'];
    $email=$_POST['email'];
    $phoneNumber=$_POST['phoneNumber'];
    $address=$_POST['address'];
    $gender=$_POST['gender'];
    $birthMonth=$_POST['birthMonth'];
    $birthDay=$_POST['birthDay'];
    $birthYear=$_POST['birthYear'];
    $password=$_POST['password'];
    $cpassword=$_POST['cpassword'];


    if($password==$cpassword){
        // Checking if the phone number already exists or not
        $existsql="SELECT * from `users` where `phone_number`='$phoneNumber'";
        $result=mysqli_query($conn,$existsql);
        $numExistRows=mysqli_num_rows($result);
        if ($numExistRows>0) {
            header("location: /school/Sign Up/signUp.php?error=phoneNumberAlreadyExists");
            exit();
        }

        // Checking if the Email already exists or not
        $existsql="SELECT * from `users` where `email`='$email'";
        $result=mysqli_query($conn,$existsql);
        $numExistRows=mysqli_num_rows($result);
        if ($numExistRows>0) {
            header("location: /school/Sign Up/signUp.php?error=emailAlreadyExists");
            exit();
        }

        $birthDate=mktime(0,0,0,$birthMonth,$birthDay,$birthYear);
        $dateOfBirth=date('Y-m-d',$birthDate);
        $hash=password_hash($password,PASSWORD_DEFAULT);

        $sql="INSERT INTO `users` (`first_name`, `last_name`, `email`, `phone_number`, `address`, `gender`, `birth_date`, `password`) VALUES ( '$fname', '$lname', '$email', '$phoneNumber', '$address', '$gender', '$dateOfBirth', '$hash')";
        $result=mysqli_query($conn,$sql);
        echo var_dump($result);
        echo mysqli_error($conn);
        if($result){
            session_start();
            $sql="SELECT * from `users` where `phone_number`='$phoneNumber'";
            $result=mysqli_query($conn,$sql);
            $row=mysqli_fetch_assoc($result);
            $_SESSION['user_id']=$row['user_id'];
            $_SESSION['user_name']=$row['first_name'] . " " . $row['last_name'];
            $_SESSION['created_account']=true;
            $_SESSION['user_fname']=$row['first_name'];
            header("location: /school/Home/index.php?signup=success");
        }
       
    }
    else{
        header("location: /school/Sign Up/signUp.php?error=passwordNoMatch");
    }


}



?>