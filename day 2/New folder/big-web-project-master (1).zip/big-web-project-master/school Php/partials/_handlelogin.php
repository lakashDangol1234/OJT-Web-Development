<?php
if ($_SERVER['REQUEST_METHOD']=='POST') {
    include '_dbconnect.php';

    $phoneNumberOrEmail=$_POST['phoneNumberOrEmail'];
    $password=$_POST['password'];

    $sql="SELECT * FROM `users` WHERE `email`='$phoneNumberOrEmail' OR `phone_number`='$phoneNumberOrEmail'";
    $result=mysqli_query($conn,$sql);
    $numExistRows=mysqli_num_rows($result);
    if($numExistRows<=0){
        header("location: /school/Login/login.php?account_created=false");
        exit();
    }
    elseif($numExistRows==1){
        while($row=mysqli_fetch_assoc($result)){
            if(password_verify($password,$row['password'])){
                session_start();
                $_SESSION['user_id']=$row['user_id'];
                $_SESSION['user_name']=$row['first_name'] . " " . $row['last_name'];
                $_SESSION['created_account']=true;
                $_SESSION['user_fname']=$row['first_name'];
                header("location: /school/Home/index.php?login=success");
            }
            else{
                header("location: /school/Login/login.php?password=nomatch");
            }
        }
    }

    

    
}
?>