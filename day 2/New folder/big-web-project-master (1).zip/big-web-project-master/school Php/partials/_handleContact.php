<?php
if($_SERVER['REQUEST_METHOD']=='POST'){
    include '_dbconnect.php';
    $name=$_POST['name'];
    $email=$_POST['email'];
    $phoneNumber=$_POST['phoneNumber'];
    $message=$_POST['message'];
    
    $sql="INSERT INTO `contactus` (`name`, `email`, `phone_number`, `message`) VALUES ('$name', '$email', '$phoneNumber', '$message')";
    
    $result=mysqli_query($conn,$sql);
    if($result){
        header("location: /school/Contact/contact.php?submission=success");
    }
    else{
        echo mysqli_error($conn);
    }
}
?>