    
            <div class="newsletter">
                <div class="newsAndOffers">
                    <h3>SIGN UP FOR NEWS AND OFFERS</h3>
                    <p>Subscribe to latest smartphones news & great deals we offer</p>
                </div>
                <div class="subscribe">
                    <input type="text" placeholder="Enter your Email">
                   <button>SUBSCRIBE</button>
                </div>
            </div>
            <div class="information">
                <div class="schoolInfo">
                    <div class="logoAndName informationChildren">
                    <img src="Images/logo.png" alt="" height="60vh">
                    <h2>Adarsha Saula Yubak Higher Secondary School</h2>
                    </div>
                    <div class="infoschooltxt">
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip</p>
                </div>
                </div>
                <div class="quickLinks informationChildren">
                    <h2>Quick links</h2>
                    <ul>
                        <li><a href="#">Join Us</a></li>
                        <li><a href="#">Maintenance</a></li>
                        <li><a href="#">Language Packs</a></li>
                        <li><a href="#">LearnPress</a></li>
                        <li><a href="#">Release Status</a></li>
                    </ul>
                </div>
                <div class="contactUs informationChildren">
                        <h2>Contact Us</h2>
                        <ul>
                            <li>Email : adarshabhiyan@gmail.com</li>
                            <li>Phone : 01-5590960</li>
                            <li>Location : Sainbu,Bungamati,Lalitpur-22</li>
                        </ul>
                    
                </div>

            </div>
        </div>
    </main>
    <footer>
        <p id="copyright-claim">Copyright &copy 2021 All rights reserved | Designed by Lakash</p>
        <span>
            <p class="copyright-info"><a href="#">Copyright notification</a></p>
            <p class="copyright-info"><a href="#">Terms of Use</a></p>
            <p class="copyright-info"><a href="#">Privacy Policy</a></p>
        </span>
    </footer>
