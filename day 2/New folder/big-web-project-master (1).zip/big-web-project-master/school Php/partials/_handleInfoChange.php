<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    session_start();

    // Handling Name change
    if (isset($_GET['changeName']) && $_GET['changeName'] == true) {
        include '_dbconnect.php';
        $first_name = $_POST['fname'];
        $last_name = $_POST['lname'];
        $user_id = $_SESSION['user_id'];
        $password = $_POST['password'];


        $sql = "SELECT `password` from `users` where `user_id`='$user_id'";
        $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_assoc($result);

        if (password_verify($password, $row['password'])) {
            $sql = "UPDATE  `users` set `first_name`='$first_name',`last_name`='$last_name' where `user_id`='$user_id'";
            $result = mysqli_query($conn, $sql);
            $_SESSION['user_fname'] = $first_name;
            $_SESSION['user_name'] = $first_name . " " . $last_name;
            if ($result) {
                header("location: /school/Home/index.php?changeName=true");
                exit();
            }
        } else {
            header("location: /school/User Profile/More Settings/changing user details/name_change.php?incorrectPassword=true");
            exit();
        }
    }



    // Using separate update function for email and phone Number because they are unique constraints
    function updateFunctionForUniqueConstraints($pass, $user_id, $columnName, $updating_value, $fileName, $get_param = null)
    {
        include '_dbconnect.php';

        // checking if the email or phone Number already exists or not
        $sql = "SELECT * from `users` where `$columnName`='$updating_value'";
        $result = mysqli_query($conn, $sql);
        $numOfRowExists = mysqli_num_rows($result);

        // if email or phone number does not exists if condition will execute
        if ($numOfRowExists == 0) {
            $sql = "SELECT `password` from `users` where `user_id`='$user_id'";
            $result = mysqli_query($conn, $sql);
            $row = mysqli_fetch_assoc($result);


            if (password_verify($pass, $row['password'])) {
                $sql = "UPDATE  `users` set `$columnName`='$updating_value' where `user_id`='$user_id'";
                $result = mysqli_query($conn, $sql);
                if ($result) {
                    header("location: /school/Home/index.php?$get_param");
                    exit();
                }
            } else {
                header("location: /school/User Profile/More Settings/changing user details/" . $fileName . "?incorrectPassword=true");
                exit();
            }
        } else {
            if($columnName=="email"){
            header("location: /school/User Profile/More Settings/changing user details/" . $fileName . "?emailAlreadyExists=true");
            exit();
            }
            else if($columnName=="phone_number"){
            header("location: /school/User Profile/More Settings/changing user details/" . $fileName . "?phoneNumberAlreadyExists=true");
            exit();
            }

        }
    }

    // Handling Email change
    if (isset($_GET['changeEmail']) && $_GET['changeEmail'] == true) {
        $email = $_POST['email'];
        $user_id = $_SESSION['user_id'];
        $password = $_POST['password'];
        $columnName = 'email';
        $get_param = 'changeEmail=true';
        $fileName = 'email_change.php';
       updateFunctionForUniqueConstraints($password, $user_id, $columnName, $email, $fileName, $get_param);
    }

    // Handling Phone Number change
    if (isset($_GET['changePhoneNumber']) && $_GET['changePhoneNumber'] == true) {
        $phone_number = $_POST['phone_number'];
        $user_id = $_SESSION['user_id'];
        $password = $_POST['password'];
        $columnName = 'phone_number';
        $get_param = 'changePhoneNumber=true';
        $fileName = 'phoneNumber_change.php';
        updateFunctionForUniqueConstraints($password, $user_id, $columnName, $phone_number, $fileName, $get_param);

    }



    // Making Update function for updating the given values that does not contain unique constraints and implementing DRY
    function updateFunction($pass, $user_id, $columnName, $updating_value, $fileName, $get_param = null)
    {
        include '_dbconnect.php';
        $sql = "SELECT `password` from `users` where `user_id`='$user_id'";
        $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_assoc($result);


        if (password_verify($pass, $row['password'])) {
            $sql = "UPDATE  `users` set `$columnName`='$updating_value' where `user_id`='$user_id'";
            $result = mysqli_query($conn, $sql);
            if ($result) {
                header("location: /school/Home/index.php?$get_param");
                exit();
            }
        } else {
            header("location: /school/User Profile/More Settings/changing user details/" . $fileName . "?incorrectPassword=true");
            exit();
        }
    }








    // Handling Address change
    if (isset($_GET['changeAddress']) && $_GET['changeAddress'] == true) {
        $address = $_POST['address'];
        $user_id = $_SESSION['user_id'];
        $password = $_POST['password'];
        $columnName = 'address';
        $get_param = 'changeAddress=true';
        $fileName = 'phoneNumber_change.php';
        updateFunction($password, $user_id, $columnName, $email, $fileName, $get_param);
    }

    // Handling Gender change
    if (isset($_GET['changeGender']) && $_GET['changeGender'] == true) {
        $user_id = $_SESSION['user_id'];

        $gender = $_POST['gender'];
        $password = $_POST['password'];
        $columnName = 'gender_change.php';

        $get_param = 'gender_change=true';
        $fileName = 'gender';
        updateFunction($password, $user_id, $columnName, $email, $fileName, $get_param);
    }

    // Handling Birth Date change
    if (isset($_GET['changeBirthDate']) && $_GET['changeBirthDate'] == true) {
        $user_id = $_SESSION['user_id'];

        $birthMonth = $_POST['birthMonth'];
        $birthDay = $_POST['birthDay'];
        $birthYear = $_POST['birthYear'];
        $password = $_POST['password'];
        $columnName = 'birth_date';
        $get_param = 'dateOfBirth_change=ture';

        // Making date time
        $birthDate = mktime(0, 0, 0, $birthMonth, $birthDay, $birthYear);
        $dateOfBirth = date('Y-m-d', $birthDate);
        $fileName = 'birthDate_change.php';
        updateFunction($password, $user_id, $columnName, $email, $fileName, $get_param);
    }

    // Handling password change
    if (isset($_GET['changePassword']) && $_GET['changePassword'] == true) {
        $user_id = $_SESSION['user_id'];

        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];
        $confirm_new_password = $_POST['confirm_new_password'];
        if ($new_password == $confirm_new_password) {
            include '_dbconnect.php';
            $sql = "SELECT `password` from `users` where `user_id`='$user_id'";
            $result = mysqli_query($conn, $sql);
            $row = mysqli_fetch_assoc($result);

            if (password_verify($current_password, $row['password'])) {
                $hash = password_hash($new_password, PASSWORD_DEFAULT);
                $sql = "UPDATE  `users` set `password`='$hash' where `user_id`='$user_id'";
                $result = mysqli_query($conn, $sql);
                if ($result) {
                    header("location: /school/Home/index.php?password_change=true");
                    exit();
                }
            } else {
                header("location: /school/User Profile/More Settings/changing user details/password_change.php?incorrectPassword=true");
                exit();
            }
        } else {
            header("location: /school/User Profile/More Settings/changing user details/password_change.php?passwordDonotMatch=true");
            exit();
        }
    }
}
