let dismiss=document.getElementById('dismiss');

let alertMsg=document.getElementById('alertMsg');


dismiss.addEventListener('click',(e)=>{
alertMsg.style.display="none";    
window.location="/school/Home/index.php";
})


setTimeout(() => {
alertMsg.style.display="none";

// changing window location to remove the GET so that if we refresh the page alert box will not come
window.location="/school/Home/index.php";

}, 5000);


