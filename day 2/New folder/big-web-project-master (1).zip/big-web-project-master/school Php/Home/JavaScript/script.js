// console.log("Hello console");

// Giving id of activeNavBar to Home so that it can be highlighted in the nav bar
let home=document.getElementsByClassName('navMenu')[0];
home.firstChild.id='activeNavBar';




//container of slider and texts
let slider=document.querySelector('.slider');

// For dots
let dot1 = document.getElementById('dot1');
let dot2 = document.getElementById('dot2');
let dot3 = document.getElementById('dot3');

// For slider
let SliderImg = document.getElementById('sliderImg');
let previousImg = document.getElementById('previousSlider');
let nextImg = document.getElementById('nextSlider');

let myslider = ['slider_1.jpg', 'slider_2.jpg', 'slider_3.jpg'];
let i = 0; // Current Index
// console.log(i);
let sliderText = document.getElementById('sliderText');
let sliderHeading = document.getElementById('sliderHeading')


// When next button is clicked
nextImg.addEventListener('click', nextImage);


    function nextImage(){
    // length of the slider is 3
    if (i < myslider.length-1) {
        i++;
    }
    else {
        i = 0;
    }
    //    console.log(i);
    SliderImg.innerHTML = `<img src="Images/${myslider[i]}" alt="School Images">`;
    if (i == 0) {
        dot1.classList.add("dotactive");
        dot2.classList.remove("dotactive");
        dot3.classList.remove("dotactive");
        let Createdh2=document.querySelector('#Createdh2');
        // console.log(Createdh2);
        Createdh2.remove();
        sliderHeading.innerHTML = `The Premium System Education`;
        sliderHeading.style.left="12%";
        sliderHeading.style.bottom="40%";
        sliderText.innerHTML = `Future of Technology`;
        sliderText.style.left="31%";
        sliderText.style.bottom="28%";
        
    }
    
    if (i == 1) {
        dot1.classList.remove("dotactive");
        dot3.classList.remove("dotactive");
        dot2.classList.add("dotactive");
        let element = document.createElement('h2');
        element.innerText=`You only have know one thing`;
        element.id="Createdh2";
        slider.insertBefore(element, slider.firstElementChild.nextElementSibling);// adds the h2 tag dynamically as secondElementChild of slider
        element.style.left="10%";
        element.style.bottom="46%";
        element.style.fontSize="73px";
        sliderHeading.innerHTML = `You can learn anything`;
        sliderHeading.style.left="20%";
        sliderHeading.style.bottom="30%";
        sliderText.innerHTML = `Free Education`;
        sliderText.style.left="35%";
        sliderText.style.bottom="18%"
    }
    if(i==2){
        dot2.classList.remove("dotactive");
        dot3.classList.add("dotactive");
        let Createdh2=document.querySelector('#Createdh2');
        Createdh2.style.display="none";
        sliderHeading.innerHTML = `Delivering Quality Education`;
        sliderHeading.style.left="15%"
        sliderHeading.style.bottom="40%"
        sliderText.innerHTML = `AWESOME FACULTY PANEL`;
        sliderText.style.left="25%";
        sliderText.style.bottom="28%";
    }
    
} 



previousImg.addEventListener('click', () => {
    if (i < myslider.length && i != 0) {
        i--;
    }
    else {
        i = myslider.length-1;
    }
    console.log(i);
    
    SliderImg.innerHTML = `<img src="Images/${myslider[i]}" alt="School Images">`
    if (i == 0) {
        dot1.classList.add("dotactive");
        dot3.classList.remove("dotactive");
        dot2.classList.remove("dotactive");

        let Createdh2=document.querySelector('#Createdh2');
        Createdh2.remove();
        
        sliderHeading.innerHTML = `The Premium System Education`;
            sliderHeading.style.left="12%"
            sliderHeading.style.bottom="40%"
            sliderText.innerHTML = `Future of Technology`;
            sliderText.style.left="31%";
            sliderText.style.bottom="28%";
            
            
        }
        if (i == 1) {
            dot2.classList.add("dotactive");
            dot1.classList.remove("dotactive");
            dot3.classList.remove("dotactive");
            let element = document.createElement('h2');
            element.innerText=`You only have know one thing`;
            element.id="Createdh2"
            slider.insertBefore(element, slider.firstElementChild.nextElementSibling);// adds the h2 tag dynamically as secondElementChild of slider
            element.style.left="10%";
            element.style.bottom="46%";
            element.style.fontSize="73px";
            sliderHeading.innerHTML = `You can learn anything`;
            sliderHeading.style.left="20%";
            sliderHeading.style.bottom="30%";
            sliderText.innerHTML = `Free Education`;
            sliderText.style.left="35%";
            sliderText.style.bottom="18%"
        }
        if(i==2){
            dot3.classList.add("dotactive");
            dot1.classList.remove("dotactive");
            dot2.classList.remove("dotactive");
            let Createdh2=document.querySelector('#Createdh2');
            Createdh2.remove();
            sliderHeading.innerHTML = `Delivering Quality Education`;
            sliderHeading.style.left="12%"
            sliderHeading.style.bottom="40%"
            sliderText.innerHTML = `Future of Technology`;
            sliderText.style.left="31%";
            sliderText.style.bottom="28%";
        }
        
});
setInterval(() => {
    nextImage();
}, 5000);
