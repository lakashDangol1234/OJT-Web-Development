<?php
$signedUp = false;
$success = false;
$loggedin = false;
$changedName=false;
$str = "";

// Handling Sign Up alert message
if (isset($_GET['signup']) && $_GET['signup'] == "success") {
    $signedUp = true;
    $success = true;
    $str = "You are successfully signed up as ";
}


// Handling Login alert message
$loggedin = false;
if (isset($_GET['login']) && $_GET['login'] == "success") {
    $loggedin = true;
    $success = true;
    $str = "You are successfully logged in as ";
}

# Handling Changing User info Details
if (isset($_GET['changeName']) and $_GET['changeName'] == true) {
    $success = true;
    $changedName = true;
    $str = "Your Name is changed successfully to ";
}

function infoChangeHandler($get_request, $msg)
{
    if (isset($_GET[$get_request]) and $_GET[$get_request] == true) {
        global $success, $str;
        $success = true;
        $str = $msg;
    }
}

// Email changing alert
infoChangeHandler("changeEmail", "Your Email is changed successfully");

// Phone Number changing alert
infoChangeHandler("changePhoneNumber", "Your Phone Number is changed successfully");

// Address changing alert
infoChangeHandler("changeAddress", "Your Address is changed successfully");

// Gender changing alert
infoChangeHandler("gender_change", "Gender changed");

// Date Of Birth changing alert
infoChangeHandler("dateOfBirth_change", " is changed successfully");

// Password changing alert
infoChangeHandler("password_change", "Your Password is changed successfully");

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adarsha Saula Yubak Secondary School</title>
    <link rel="icon" type="image/png" href="Images/logo.png">
    <link rel="stylesheet" href="../partials/_nav.css">
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="../partials/_footer.css">
    <link rel="stylesheet" href="CSS/alertMsg.css">
    <link rel="stylesheet" href="CSS/response.css">
</head>

<body>
    <?php include '../partials/_nav.php' ?>

    <main>
        <?php
        if ($success) {
            $username = $_SESSION['user_name'];
            echo '<div id="alertMsg">
           <p id="msg"><b>Success! </b>';
            if ($loggedin or $signedUp or $changedName) {
                echo $str . $username;
            }
            else{
                echo $str;
            }
            echo '</p>
            <button id="dismiss">X</button>
        </div>';
        }
        ?>
        <div class="container">
            <div class="slider">
                <div id="sliderImg">
                    <img src="Images/slider_1.jpg" alt="School Images">
                </div>
                <h2 id="sliderHeading">The Premium System Education</h2>
                <p id="sliderText">Future of Technology</p>
                <span class="dot dotactive" id="dot1"></span>
                <span class="dot" id="dot2"></span>
                <span class="dot" id="dot3"></span>
                <button id="nextSlider">&gt;</button>
                <button id="previousSlider">
                    &lt; </button>
            </div>
            <div class="welcome">
                <h1>Welcome To Adarsha Saula Yubak Higher Secondary School</h1>
                <p>Lorem ipsum dolor siitationem animi iusto. Veritatis dolor, dolore qui accusamus delectus ad
                    dolorem facilis.</p>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eum, exercitationem?</p>
                <p> Lorem ipsum dolor sit amet, conebore et dolore magna </p>
            </div>
            <div class="features">
                <div class="experts childFeature">
                    <img src="Images/Theexperts.webp" alt="">
                    <h3>The Experts</h3>
                    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Natus, enim.</p>
                </div>
                <div class="bookLibrary childFeature">
                    <img src="Images/bookandLibrary.webp" alt="">
                    <h3>Book & Library</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse, cum.</p>
                </div>
                <div class="bestCourses childFeature">
                    <img src="Images/bestCourses.webp" alt="">
                    <h3>Best Courses</h3>
                    <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Consequuntur, magnam.</p>
                </div>
                <div class="awardReward childFeature">
                    <img src="Images/awardreward.webp" alt="">
                    <h3>Award & Reward</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nihil, neque.</p>

                </div>

            </div>
            <div class="popularClasses">
                <div class="heading">
                    <h1>Popular Courses</h1>
                    <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dolor perferendis repudiandae tempore fuga deserunt.</p>
                    <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Et magni rerum delectus labore amet ad!</p>
                </div>
                <div class="classContent">
                    <div class="science classContentChildren">
                        <img src="Images/Science.webp" alt="scienceEducation" class="courseImg">
                        <div class="txt">
                            <h3>Science</h3>
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quidem ex molestias voluptates minima incidunt iste.</p>
                        </div>

                    </div>
                    <div class="Management classContentChildren">
                        <img src="Images/Management.webp" alt="HumanitiesManagement" class="courseImg">
                        <div class="txt">
                            <h3>Management</h3>
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Illo, quo natus dolorem pariatur consectetur laboriosam!</p>
                        </div>

                    </div>
                    <div class="ComputerEngineering classContentChildren">
                        <img src="Images/Computer Engineering.webp" alt="ComputerEngineering" class="courseImg">
                        <div class="txt">
                            <h3>Computer Engineering</h3>
                            <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Officia amet dolorem repellat reprehenderit obcaecati alias.</p>
                        </div>

                    </div>
                </div>
                <div class="btn">
                    <button onclick="window.location='/school/Courses/courses.php'">View All Courses</button>
                </div>
            </div>
            <div class="admission">
                <div class="imgBox">
                    <img src="Images/Admission.png" alt="Admission">
                </div>
                <div class="admissionTxt">
                    <h1>Apply for Admission</h1>
                    <p>
                        Lorem ipsum dolor sit amet,Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quae dolore pariatur modi velit consectetur accusantium minima debitis optio quisquam! consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum
                    </p>
                    <button>Apply</button>
                </div>
            </div>
            <div class="research">
                <div class="researchTxt">
                    <h1>Research</h1>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
                </div>
                <div class="imgResearch">
                    <img src="Images/ResearchBooks.png" alt="">
                </div>
            </div>
            <div class="newsContainer">
                <h1 id="headingNews">News</h1>
                <div class="news">
                    <div class="technology">
                        <img src="Images/technologyNews.png" alt="Technology News">
                        <div class="technologyheading newsTopic">
                            <h1>Technology</h1>
                        </div>
                        <div class="technologyHeadingContent">
                            <p>Pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum</p>
                        </div>
                    </div>
                    <div class="education">
                        <img src="Images/EducationNews.png" alt="Education News">
                        <div class="educationheading newsTopic">
                            <h1>Education</h1>
                        </div>
                        <div class="educationHeadingContent">
                            <p>Pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum</p>
                        </div>
                    </div>
                </div>
            </div>
            <?php include '../partials/_footer.php' ?>
</body>
<script src="JavaScript/script.js"></script>
<?php
if ($success) {
    echo '<script src="JavaScript/alertMsgJs.js"></script>';
}
?>


</html>