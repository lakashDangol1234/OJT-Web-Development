console.log("Hello console");
 
let firstName=document.getElementById('firstName');
let lastName = document.getElementById('lastName');
let emailid=document.getElementById('emailid');
let phoneNumber=document.getElementById('phoneNumber');
let address = document.getElementById('address');
let birthDay= document.getElementById('birthDay');
let birthYear=document.getElementById('birthYear');
let newPassword = document.getElementById('newPassword');
let reTypePassword = document.getElementById('reTypePassword');
let validFirstName = false;
let validLastName = false;
let validEmailid= false;
let validPhoneNumber = false;
let validAddress = false;
let validBirthDay = false;
let validBirthYear=false;
let validNewPassword = false;
let validReTypePassword = false;

firstName.addEventListener('blur',()=>{
    let str=firstName.value;
    let regexfirstName=/^[A-Za-z]([A-Za-z]){1,10}(\s+?([A-Za-z]){1,10})?$/;
    if (regexfirstName.test(str)) {
        firstName.style.border="2px solid green";
        validFirstName = true;
        
    }
    else{
        firstName.style.border="2px solid red";
        validFirstName = false;
    }
})
lastName.addEventListener('blur',()=>{
    let str=lastName.value;
    let regexlastName=/^[A-Za-z]([A-Za-z]){1,10}$/;
    if (regexlastName.test(str)) {
        lastName.style.border="2px solid green";
        validLastName = true;
        
    }
    else{
        lastName.style.border="2px solid red";
        validLastName = false;
    }
})
emailid.addEventListener('blur',()=>{
    let str=emailid.value;
    let regexemailid=/^([a-zA-Z0-9\.\-\_]+)@([a-zA-Z0-9\.\-\_]+)\.([a-zA-Z]){2,7}$/;
    if (regexemailid.test(str)) {
        emailid.style.border="2px solid green";
        validEmailid= true;
        
    }
    else{
        emailid.style.border="2px solid red";
        validEmailid= false;
    }
})
emailid.addEventListener('blur',()=>{
    let str=emailid.value;
    let regexemailid=/^([a-zA-Z0-9\.\-\_]+)@([a-zA-Z0-9\.\-\_]+)\.([a-zA-Z]){2,7}$/;
    if (regexemailid.test(str)) {
        emailid.style.border="2px solid green";
        
    }
    else{
        emailid.style.border="2px solid red";
    }
})
phoneNumber.addEventListener('blur',()=>{
    let str=phoneNumber.value;
    let regexphoneNumber=/^[0-9]([0-9]){9}$/;
    if (regexphoneNumber.test(str)) {
        
        phoneNumber.style.border="2px solid green";
        validPhoneNumber = true;
        
    }
    else{
        
        phoneNumber.style.border="2px solid red";
        validPhoneNumber = false;
    }
})
address.addEventListener('blur',()=>{
    let str=address.value;
    let regexaddress=/^[A-Za-z]([A-Za-z\,]+){1,10}(\s?[,])?(\s+?([A-Za-z\,]){1,10})?$/;
    if (regexaddress.test(str)) {
        
        address.style.border="2px solid green";
        validAddress = true;
        
    }
    else{
        
        address.style.border="2px solid red";
        validAddress = false;
    }
})
birthDay.addEventListener('blur',()=>{
    let str=birthDay.value;
    let regexbirthDay=/^[0-9]([0-9]){0,1}$/;
    if (regexbirthDay.test(str) && str<32) {
        
        birthDay.style.border="2px solid green";
        validBirthDay = true;
        
    }
    else{
        
        birthDay.style.border="2px solid red";
        validBirthDay = false;
    }
})
birthYear.addEventListener('blur',()=>{
    let str=birthYear.value;
    let regexbirthYear=/^[0-9]([0-9]){0,3}$/;
    if (regexbirthYear.test(str) && str<2022) {
        
        birthYear.style.border="2px solid green";
        validBirthYear=true;
        
    }
    else{
        
        birthYear.style.border="2px solid red";
        validBirthYear=false;
    }
});

newPassword.addEventListener('blur', () => {
    let str = newPassword.value;
    let regexPassword =/^([A-z@#$%&\^\*0-9\s]){5,10}$/;

    
    if (regexPassword.test(str)) {
        newPassword.style.border = "2px solid green";
        validNewPassword = true;
    }
    else {
        newPassword.style.border="2px solid red";
        validNewPassword = false;
    }
});
reTypePassword.addEventListener('blur', () => {
    let str = reTypePassword.value;
    let regexPassword =/^([A-z@#$%&\^\*0-9\s]){5,10}$/;

    
    if (regexPassword.test(str) && str==newPassword.value) {
        reTypePassword.style.border = "2px solid green";
        validReTypePassword = true;
    }
    else {
        reTypePassword.style.border="2px solid red";
        validReTypePassword = false;
    }
});

// for hiding and showing password
let showPassword=document.getElementById('showPassword');
let confirmShowpassword = document.getElementById('confirmShowpassword');


showPassword.addEventListener('click',()=>{
    if (newPassword.type=='password') {
        newPassword.type='text';
    }
    else{
        newPassword.type='password';
    }
});
confirmShowpassword.addEventListener('click',()=>{
    if (reTypePassword.type=='password') {
        reTypePassword.type='text';
    }
    else{
        reTypePassword.type='password';
    }
});
window.addEventListener('load',()=>{
    showPassword.checked=false;
    confirmShowpassword.checked=false;
})


let signUpbtn = document.getElementById('signUpbtn');
signUpbtn.addEventListener('click',(e)=>{
    e.preventDefault();
    if (validFirstName && validLastName && validEmailid && validPhoneNumber && validAddress && validBirthDay && validBirthYear && validNewPassword && validReTypePassword) {
    console.log('successfully signed up');
    
    }
    else{
        console.log('Failed Please try again');
        if(!validFirstName){
            firstName.style.border="2px solid red";
        }
        if(!validLastName){
            lastName.style.border="2px solid red";
        }
        if(!validEmailid){
            emailid.style.border="2px solid red";

        }
        if(!validPhoneNumber){
            phoneNumber.style.border="2px solid red";
           
        }
        if(!validAddress){
            address.style.border="2px solid red";
        }
        if(!validBirthDay){
            birthDay.style.border="2px solid red";
        }
        if(!validBirthYear){
            birthYear.style.border="2px solid red";
        }
        if(!validNewPassword){
            newPassword.style.border="2px solid red";
        }
        if(!validReTypePassword){
            reTypePassword.style.border="2px solid red";
        }
        
    }
})
