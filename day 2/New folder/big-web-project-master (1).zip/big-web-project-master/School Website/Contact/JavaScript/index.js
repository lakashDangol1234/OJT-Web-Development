
// validation condition
let validName=false;
let validEmail=false;
let validPhonenumber=false;

//grabing input box
let name=document.getElementById('name');
let email=document.getElementById('email');
let phoneNumber = document.getElementById('phoneNumber');
name.addEventListener('blur',()=>{
     let str=name.value;
     let regexName=/^[A-Za-z]([A-Za-z]){1,10}(\s+?([A-Za-z]){1,10})?$/;
     if(regexName.test(str)){
        name.className='Truevalidation';
        validName=true;
        let nameValid=document.getElementById('nameValid');
        nameValid.style.display="block";
        nameValid.style.color="green";
        nameValid.innerHTML=`Your name is valid`;
        
     }
     else{
        // Your username must be 2-10 characters long and should not contain with a number or symbols
         name.className='Falsevalidation';
         validName=false;
         let nameValid=document.getElementById('nameValid');
         nameValid.style.display="block";
         nameValid.innerHTML=`Your username must be 2-10 characters long and should not contain with a number or symbols`;
         nameValid.style.color="red";

     }
});
email.addEventListener('blur',()=>{
     let str=email.value;
     let regexEmail=/^([a-zA-Z0-9\.\-\_]+)@([a-zA-Z0-9\.\-\_]+)\.([a-zA-Z]){2,7}$/;
     if(regexEmail.test(str)){
        email.className='Truevalidation';
        validEmail=true;
        let emailValid = document.getElementById('emailValid');
        emailValid.style.color="green";
        emailValid.style.display="block";
        emailValid.innerHTML=`Your email is invalid`;
        
     }
     else{
         email.className='Falsevalidation';
         validEmail=false;
         let emailValid = document.getElementById('emailValid');
         emailValid.style.display="block";
         emailValid.style.color="red";
         emailValid.innerHTML=` Your email must be a valid email`;
         
         
     }
});
phoneNumber.addEventListener('blur',()=>{
     let str=phoneNumber.value;
     let regexPhoneNumber=/^[0-9]([0-9]){9}$/;
     if(regexPhoneNumber.test(str)){
        phoneNumber.className='Truevalidation';
        validPhonenumber=true;
        let phonenumberValid=document.getElementById('phonenumberValid');
        phonenumberValid.style.display="block";
        phonenumberValid.style.color="green";
        phonenumberValid.innerHTML=`Your phone number is valid`;
     }
     else{
         phoneNumber.className='Falsevalidation';
         validPhonenumber=false;
         let phonenumberValid = document.getElementById('phonenumberValid');
         phonenumberValid.style.display="block";
         phonenumberValid.style.color="red";
         phonenumberValid.innerHTML=` Your phone number must be 10 digit long`;
     }
});

// grabing submit button
let submitBtn=document.getElementById('submitBtn');
submitBtn.addEventListener('click',(e)=>{
    e.preventDefault();
    let visiblepopUpMsg=document.querySelector('.visiblepopUpMsg');
    let dismissableBtn = document.getElementById('dismissableBtn');
    let bold=document.getElementById('bold');
    let alertmsg = document.getElementById('alertmsg');
    let messageBox = document.getElementById('messageBox');
    let popUpBgcolor = document.getElementById('popUpBgcolor');

 
    if(validName && validEmail && validPhonenumber){
       bold.innerHTML=`Success !`;
       bold.classList.add('boldSuccess');
       bold.classList.remove('boldError');
       messageBox.classList.add('messageBoxSuccess');
       messageBox.classList.remove('messageBoxError');
       alertmsg.innerHTML=`Your request has been successfully submitted`;
       alertmsg.classList.add('alertmsgSuccess');
       alertmsg.classList.remove('alertmsgError');
       dismissableBtn.style.marginLeft="724px";
       popUpBgcolor.style.backgroundColor="#d4edda";
       visiblepopUpMsg.classList.remove('visiblepopUpMsg');
       dismissableBtn.style.color="#73a17e";
       dismissableBtn.addEventListener('click',()=>{
           popUpBgcolor.classList.add("visiblepopUpMsg")
       })
      setTimeout(() => {
        popUpBgcolor.classList.add("visiblepopUpMsg")
      }, 5000);
       
       
    }
    else{
        bold.innerHTML=`Error !`;
        messageBox.classList.add('messageBoxError');
        messageBox.classList.remove('messageBoxSuccess');
        bold.classList.add('boldError');
        bold.classList.remove('boldSuccess');
        alertmsg.innerHTML=`Your request has not been sent due to errors`;
        alertmsg.classList.add('alertmsgError');
        alertmsg.classList.remove('alertmsgSuccess');
        visiblepopUpMsg.classList.remove('visiblepopUpMsg');
      
        popUpBgcolor.style.backgroundColor="#f8d7da";
        
          dismissableBtn.addEventListener('click',()=>{
            popUpBgcolor.classList.add("visiblepopUpMsg")
        })
       setTimeout(() => {
         popUpBgcolor.classList.add("visiblepopUpMsg")
       }, 5000);
    }
})
